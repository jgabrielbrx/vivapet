import "./UltimasAtividades.css"

export default function UltimasAtividades(){
    return(
        <section className="ultimas-atividades">
            <h1>Últimas Atividades</h1>
            <ul>
                <li>Novo animal cadastrado: Bob</li>
                <li>Novo cuidador Registrado: Marcos Laurencio</li>
                <li>Novo animal cadastrado: Athos</li>
                <li>Novo suprimento cadastrado: Ração</li>
            </ul>
        </section>
    )
}